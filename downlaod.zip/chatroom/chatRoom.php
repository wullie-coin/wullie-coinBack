<!DOCTYPE html>
<link rel="stylesheet" type="text/css" href="chatRoom.css">
<html>
	
	<head>
	
	<title> wullie coin chat room </title>

	</head>

	<body>
		
		<p>Welcome user to the Wullie Coin chat room <br> </p>
	
	</body>

</html>


